<?php
echo "<!DOCTYPE html>";
echo '<html lang="zh-Hant">';
echo '<head>';
echo '<meta charset="utf-8">';
echo '<title>網頁標題</title>';
echo "</head>";
echo "<body>";
echo 10+10+10+10;
echo "</body>";
echo "</html>";