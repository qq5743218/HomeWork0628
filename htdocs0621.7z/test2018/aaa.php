<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<title>網頁標題</title>
</head>
<body>
<?php
if( 10==20 ){
	echo "<b>ooooo</b>";
}else{
	echo "<i>ooooo</i>";
}
?>
bbbb
cccc
dddd
<?php echo "xxxxx"; ?>
eeee
</body>
</html>